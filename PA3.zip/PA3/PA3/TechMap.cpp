#include <iostream>
#include <algorithm>
#include <iomanip>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <cassert>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <cmath>
#include <limits>
#include <string.h>

#include "TechMap.h"

using namespace std;
bool compare(const Pair& p1, const Pair& p2){
    return p1.second < p2.second;
}

void Tech_map::parseLib(fstream& inFile)
{
    string str;
    double temp;

    while(!inFile.eof())
    {
        string name;
        inFile >> str;      name = str;
        str = str.substr(0, str.size() - 1);
        // cout << str << endl;
        // cout << name << endl;

        if(str.compare("INV") == 0)
        {
            Lib *lib = new Lib(name);
            // cout << name << ": ";
            inFile >> str >> str;   temp = stod(str);
            lib->setDelayBase(temp);
            // cout << temp << " ";
            inFile >> str;   temp = stod(str);
            lib->setDelayFan(temp);
            // cout << temp << " ";
            inFile >> str >> str;   temp = stod(str);
            lib->setArea(temp);
            // cout << temp << " ";
            lib->setCP();
            // cout << lib->getCP() << endl;
            _vec_lib_inv.push_back(lib);
            _map_lib_inv[name] = lib;
            ++_num_lib_inv;
        }
        else if(str.compare("NAND") == 0)
        {
            Lib *lib = new Lib(name);
            // cout << name << ": ";
            inFile >> str >> str;   temp = stod(str);
            lib->setDelayBase(temp);
            // cout << temp << " ";
            inFile >> str;   temp = stod(str);
            lib->setDelayFan(temp);
            // cout << temp << " ";
            inFile >> str >> str;   temp = stod(str);
            lib->setArea(temp);
            // cout << temp << " ";
            lib->setCP();
            // cout << lib->getCP() << endl;
            _vec_lib_nand.push_back(lib);
            _map_lib_nand[name] = lib;
            ++_num_lib_nand;
        }
    }

    return;
}

void Tech_map::initial()
{
    // PrintEachObj();
    _num_obj = Abc_NtkObjNum(_ntk);

    // Construct PI, PO, Node
    for(int i = 0; i < _num_obj; ++i)
    {
        int index = Abc_ObjId(Abc_NtkObj(_ntk, i));
        // cout << "Name: " << Abc_ObjName(Abc_NtkObj(_ntk, i)) << ", Type: " << Abc_ObjType(Abc_NtkObj(_ntk, i)) << endl;

        if(Abc_ObjType(Abc_NtkObj(_ntk, i)) == ABC_OBJ_PI)
        {
            Node* pi = new Node(index);
            pi->setName(Abc_ObjName(Abc_NtkObj(_ntk, i)));
            pi->setGateType(ABC_OBJ_PI);
            pi->setPatternType("INPUT");
            pi->setisPI(true);

            _map_PI[i] = pi;
            // cout << "PI" << endl;
        }
        else if(Abc_ObjType(Abc_NtkObj(_ntk, i)) == ABC_OBJ_PO)         
        {
            Node* po = new Node(index);
            po->setLevel(Abc_ObjLevel(Abc_NtkObj(_ntk, i)));
            po->setName(Abc_ObjName(Abc_NtkObj(_ntk, i)));
            po->setGateType(ABC_OBJ_PO);
            po->setPatternType("OUTPUT");
            po->setisNAND(2);
            po->setisPO(true);

            _map_PO[i] = po;
            _map_node[i] = po;
            // cout << "PO" << endl;
        }
        else if(Abc_ObjType(Abc_NtkObj(_ntk, i)) == ABC_OBJ_NODE)
        {
            Node* nand = new Node(index);
            nand->setLevel(Abc_ObjLevel(Abc_NtkObj(_ntk, i)));
            nand->setName(Abc_ObjName(Abc_NtkObj(_ntk, i)));
            nand->setGateType(ABC_OBJ_NODE);
            nand->setPatternType("NAND1");
            nand->setisNAND(1);

            _map_node[i] = nand;
            // cout << "NODE" << endl;
        }
    }

    // Construct Graph
    for(int i = 0; i < _num_obj; ++i)
    {
        Abc_Obj_t *node = Abc_NtkObj(_ntk, i);

        for(int j = 0; j < Abc_ObjFaninNum(node); ++j)
        {
            Abc_Obj_t *in = Abc_ObjFanin(node, j);
            if(Abc_ObjType(in) == ABC_OBJ_PI && Abc_ObjFaninC(node, j) == 1)    // PI -> Node
            {
                ++_num_inv;
                Node* inv = new Node(_num_obj + _num_inv);
                inv->setName( "INV"+to_string(_num_inv) );
                inv->setGateType(ABC_OBJ_NODE);
                inv->setPatternType("INV1");
                inv->setisNAND(0);
                _map_node[_num_obj + _num_inv] = inv;

                Node* pi = _map_PI[ Abc_ObjId(in) ];
                pi->addFanOut(inv);
                inv->addFanIn(pi);

                Node* n = _map_node[ Abc_ObjId(node) ];
                inv->addFanOut(n);
                n->addFanIn(inv);
            }
            else if(Abc_ObjType(in) == ABC_OBJ_NODE && Abc_ObjFaninC(node, j) == 0) // Node -> Node(PO)
            {       
                if(Abc_ObjType(node) == ABC_OBJ_PO) {
                    Node* n = _map_node[ Abc_ObjId(node) ];
                    n->setisNAND(0);
                    n->setPatternType("INV1");

                    Node* ni = _map_node[ Abc_ObjId(in) ];
                    ni->addFanOut(n);
                    n->addFanIn(ni);
                }
                else {
                    ++_num_inv;
                    Node* inv = new Node(_num_obj + _num_inv);
                    inv->setName( "INV"+to_string(_num_inv) );
                    inv->setGateType(ABC_OBJ_NODE);
                    inv->setPatternType("INV1");
                    inv->setisNAND(0);
                    _map_node[_num_obj + _num_inv] = inv;

                    Node* ni = _map_node[ Abc_ObjId(in) ];
                    ni->addFanOut(inv);
                    inv->addFanIn(ni);

                    Node* n = _map_node[ Abc_ObjId(node) ];
                    inv->addFanOut(n);
                    n->addFanIn(inv);
                }    
            }
            else {
                Node* ni;
                if(Abc_ObjType(in) == ABC_OBJ_PI) {
                    ni = _map_PI[ Abc_ObjId(in) ];
                }
                else if(Abc_ObjType(in) == ABC_OBJ_NODE) {
                    ni = _map_node[ Abc_ObjId(in) ];
                }
                Node* n = _map_node[ Abc_ObjId(node) ];

                ni->addFanOut(n);
                n->addFanIn(ni);
            }
        }
    }
    return;
}

/* timing function */
void Tech_map::calATime()
{
    queue<Node*> q;
    vector<bool> visited(_num_obj + _num_inv, false);

    for(map<int, Node*>::iterator it = _map_PI.begin(); it != _map_PI.end(); ++it) {
        Node* n = it->second;
        // cout << n->getName() << " ";
        q.push(n);
    }

    while(!q.empty()) {
        Node* n = q.front();
        int num_fo = n->getFanOutSize();
        q.pop();

        // Set Arrival time
        if(!visited[n->getId()]) {
            if ( !(n->getisPI()) )
            {
                double max = 0;    // Maximum ATime of fanin
                bool v = true;
                for(int i = 0; i < n->getFanInSize(); ++i) {
                    Node* fanin = n->getFanIn(i);
                    if( !fanin->getisPI() && fanin->getATime() == 0) {
                        v = false;
                        break;
                    }
                    if(fanin->getATime() > max) {
                        max = fanin->getATime();
                    }
                }
                visited[n->getId()] = v;
                if(v) {
                    double min = (numeric_limits<double>::max)();
                    double delay;
                    if( n->getisNAND() == 0) {   // INV
                        for(int i = 0; i < _vec_lib_inv.size(); ++i) {
                            Lib *lib = _vec_lib_inv[i];
                            delay = lib->getDelayBase() + lib->getDelayFan() * num_fo;
                            if(delay < min) { 
                                min = delay;
                                n->setArea(lib->getArea());
                                n->setDelay(delay);
                                n->setPatternType(lib->getName());
                            }
                        }
                        n->setATime(max + min);     // the maximum of Fanin's Atime + the minimum of gate delay
                        if(_initialDelay < n->getATime()) { _initialDelay = n->getATime(); }
                        // cout << n->getName() << ": " << n->getATime() << endl;
                    }
                    else if( n->getisNAND() == 1) {     // NAND
                        for(int i = 0; i < _vec_lib_nand.size(); ++i) {
                            Lib *lib = _vec_lib_nand[i];
                            delay = lib->getDelayBase() + lib->getDelayFan() * num_fo;
                            if(delay < min) { 
                                min = delay;
                                n->setArea(lib->getArea());
                                n->setDelay(delay);
                                n->setPatternType(lib->getName());
                            }
                        }
                        n->setATime(max + min);     // the maximum of Fanin's Atime + the minimum of gate delay
                        if(_initialDelay < n->getATime()) { _initialDelay = n->getATime(); }
                        // cout << n->getName() << ": " << n->getATime() << endl;
                    }
                     
                }
            }
            else { n->setATime(0); }
        }


        for(int i = 0; i < n->getFanOutSize(); ++i)
        {
            Node *fanout = n->getFanOut(i);
            // cout << fanout->getName() << " ";

            if( !visited[fanout->getId()] ) {
                q.push(fanout);
            }
        }
    }
    
    return;
}

void Tech_map::calRTime()
{
    queue<Node*> q;
    vector<bool> visited(_num_obj + _num_inv, false);

    for(map<int, Node*>::iterator it = _map_PO.begin(); it != _map_PO.end(); ++it) {
        Node* n = it->second;
        // cout << n->getName() << " ";
        q.push(n);
        visited[n->getId()] = true;
    }
    
    while(!q.empty()) {
        Node* n = q.front();
        int num_fi = n->getFanInSize();
        q.pop();

        bool v = true;
        if ( !(n->getisPO()) )
        {
            double min = (numeric_limits<double>::max)();;    // Minimum RTime of fanin
                
            for(int i = 0; i < n->getFanOutSize(); ++i) {
                Node* fanout = n->getFanOut(i);
                if(fanout->getRTime() == 0) {
                        v = false;
                        q.push(n);
                        break;
                }
                double temp = fanout->getRTime() - fanout->getDelay();
                if(temp < min) {
                    min = temp;
                }
            }
            if(v)   n->setRTime(min);
        }
        else { n->setRTime(_initialDelay); }

        if(v) {
            for(int i = 0; i < n->getFanInSize(); ++i)
            {
                Node *fanin = n->getFanIn(i);
                // cout << fanout->getName() << " ";

                if( !visited[fanin->getId()] ) {
                    visited[fanin->getId()] = true;
                    q.push(fanin);
                }
            }
        }
    }
    return;
}

void Tech_map::calSlack()
{
    for(map<int, Node*>::iterator it = _map_PI.begin(); it != _map_PI.end(); ++it) {
        Node* n = it->second;
        n->setSlack();
        n->setCritical();

        // cout << n->getName() << ": " << n->getSlack() << endl;
    }
    for(map<int, Node*>::iterator it = _map_node.begin(); it != _map_node.end(); ++it) {
        Node* n = it->second;
        // string type = n->getPatternType();
        // if(type.compare("OUTPUT") == 0) {
        //     n->setCritical();
        //     continue;
        // }
        n->setSlack();
        n->setCritical();

        // cout << n->getName() << ": " << n->getSlack() << endl;
    }
    return;
}
/* timing function */

double Tech_map::calArea()
{
    double area = 0;
    for(map<int, Node*>::iterator it = _map_node.begin(); it != _map_node.end(); ++it) {
        area += it->second->getArea();
    }
    return area;
}

void Tech_map::updateATime(Node* node)
{
    queue<Node*> q;
    vector<bool> visited(_num_obj + _num_inv, false);
    // vector<bool> visited(_num_obj + _num_inv, false);

    q.push(node);
    visited[node->getId()] = true;
    while(!q.empty()) {
        Node* n = q.front();
        // cout << n->getName() << " ";
        int num_fo = n->getFanOutSize();
        q.pop();
        // clear output cone's ATime
        for(int i = 0; i < n->getFanOutSize(); ++i)
        {
            Node *fanout = n->getFanOut(i);
            if( !visited[fanout->getId()]) { 
                fanout->setATime(0);
            }
        }
        bool v = true;
        double max = 0;    // Maximum ATime of fanin
            
        for(int i = 0; i < n->getFanInSize(); ++i) {
            Node* fanin = n->getFanIn(i);
            if(!fanin->getisPI() && fanin->getATime() == 0) {
                    v = false;
                    q.push(n);
                    break;
            }
            if(fanin->getATime() > max) {
                max = fanin->getATime();
            }
        }
        // visited[n->getId()] = v;
        if(v) {
            if(n->getisNAND() == 0) {   //INV
                Lib *lib = _map_lib_inv[n->getPatternType()];
                double delay = lib->getDelayBase() + lib->getDelayFan() * num_fo;
                n->setDelay(delay);
                n->setATime(max + delay);
            }
            else if(n->getisNAND() == 1) {  // NAND
                Lib *lib = _map_lib_nand[n->getPatternType()];
                double delay = lib->getDelayBase() + lib->getDelayFan() * num_fo;
                n->setDelay(delay);
                n->setATime(max + delay);
            }

            for(int i = 0; i < n->getFanOutSize(); ++i)
            {
                Node *fanout = n->getFanOut(i);
                // cout << fanout->getName() << " ";

                if( !visited[fanout->getId()] ) {
                    visited[fanout->getId()] = true;
                    q.push(fanout);
                }
            }
        }
        
    }
    return;
}

void Tech_map::updateRTime(Node* node)
{
    queue<Node*> q;
    vector<bool> visited(_num_obj + _num_inv, false);

    q.push(node);
    visited[node->getId()] = true;
    while(!q.empty()) {
        Node* n = q.front();
        int num_fi = n->getFanInSize();
        q.pop();
        // clear input cone's RTime
        for(int i = 0; i < n->getFanInSize(); ++i)
        {
            Node *fanin = n->getFanIn(i);
            if( !visited[fanin->getId()] ) { fanin->setRTime(0); }
        }
        bool v = true;
        if ( !(n->getisPO()) )
        {
            double min = (numeric_limits<double>::max)();;    // Minimum RTime of fanin
                
            for(int i = 0; i < n->getFanOutSize(); ++i) {
                Node* fanout = n->getFanOut(i);
                if(fanout->getRTime() == 0) {
                        v = false;
                        q.push(n);
                        break;
                }
                double temp = fanout->getRTime() - fanout->getDelay();
                if(temp < min) {
                    min = temp;
                }
            }
            if(v)   n->setRTime(min);
        }
        // visited[n->getId()] = v;
        if(v) {
            for(int i = 0; i < n->getFanInSize(); ++i)
            {
                Node *fanin = n->getFanIn(i);
                // cout << fanout->getName() << " ";

                if( !visited[fanin->getId()] ) {
                    visited[fanin->getId()] = true;
                    q.push(fanin);
                }
            }
        }
    }
    return;
}

bool Tech_map::updateSlack(Node* node)
{
    // cout << "====================" << endl;
    updateATime(node);
    // cout << "updateATime" << endl;
    updateRTime(node);
    // cout << "updateRTime" << endl;
    for(map<int, Node*>::iterator it = _map_PI.begin(); it != _map_PI.end(); ++it) {
        Node* n = it->second;
        n->setSlack();
        if(!n->getCritical()) {
            if(n->getSlack() < 0.01) return false;
        }
        else {
            if(n->getSlack() < -10e9) return false;
        }

        // cout << n->getName() << ": " << n->getSlack() << endl;
    }
    for(map<int, Node*>::iterator it = _map_node.begin(); it != _map_node.end(); ++it) {
        Node* n = it->second;
        n->setSlack();
        if(!n->getCritical()) {
            if(n->getSlack() < 0.01) return false;
        }
        else {
            if(n->getSlack() < -10e9) return false;
        }

        // cout << n->getName() << ": " << n->getSlack() << endl;
    }
    // cout << "------------" << endl;
    return true;
}

void Tech_map::updateCritical()
{
    for(map<int, Node*>::iterator it = _map_PI.begin(); it != _map_PI.end(); ++it) {
        it->second->setCritical();
    }
    for(map<int, Node*>::iterator it = _map_node.begin(); it != _map_node.end(); ++it) {
        Node* n = it->second;
        string type = n->getPatternType();
        // if(type.compare("OUTPUT") == 0) {
        //     continue;
        // }
        n->setCritical();
    }
    return;
}

void Tech_map::Approach()
{
    vector<Pair> cp_inv;
    vector<Pair> cp_nand;
    vector<Pair> node_s;
    for(int i = 0; i < _vec_lib_inv.size(); ++i) {
        Lib *l = _vec_lib_inv[i];
        cp_inv.push_back(make_pair(i, l->getCP()));
    }
    for(int i = 0; i < _vec_lib_nand.size(); ++i) {
        Lib *l = _vec_lib_nand[i];
        cp_nand.push_back(make_pair(i, l->getCP()));
    }
    for(map<int, Node*>::iterator it = _map_node.begin(); it != _map_node.end(); ++it) {
        if(!it->second->getCritical())
            node_s.push_back(make_pair(it->first, it->second->getSlack()));
    }
    sort(cp_inv.begin(), cp_inv.end(), compare);
    reverse(cp_inv.begin(), cp_inv.end());
    sort(cp_nand.begin(), cp_nand.end(), compare);
    reverse(cp_nand.begin(), cp_nand.end());
    sort(node_s.begin(), node_s.end(), compare);
    reverse(node_s.begin(), node_s.end());
    
    for(int i = 0; i < node_s.size(); ++i) {
        // cout << _map_node[ node_s[i].first ]->getName() << endl;
        Node* n = _map_node[ node_s[i].first ];
        // cout << n->getCritical() << endl;
        // cout << n->getName() << ": " << n->getSlack() << " " << n->getCritical() << ", ";
        if(!n->getCritical()) {
            
            if(n->getisNAND() == 0) {   // INV
                string type = n->getPatternType();
                bool d = false;  // check whether the node is change
                for(int j = 0; j < cp_inv.size(); ++j) {
                    Lib *l = _vec_lib_inv[ cp_inv[j].first ];
                    n->setPatternType(l->getName());
                    if(updateSlack(n)) {
                        d = true;
                        n->setArea(l->getArea());
                        break;
                    }
                }
                if(!d) {
                    n->setPatternType(type);
                    updateSlack(n);
                }
            }
            else if(n->getisNAND() == 1) {   // NAND
                string type = n->getPatternType();
                bool d = false;  // check whether the node is change
                for(int j = 0; j < cp_nand.size(); ++j) {
                    Lib *l = _vec_lib_nand[ cp_nand[j].first ];
                    n->setPatternType(l->getName());
                    if(updateSlack(n)) {
                        d = true;
                        n->setArea(l->getArea());
                        break;
                    }
                }
                if(!d) {
                    n->setPatternType(type);
                    updateSlack(n);
                }
            }
            updateCritical();
        }
    }
    return;
}

void Tech_map::techmap()
{
    // cout << "=========== Arrival Time ===========" << endl;
    calATime();
    // cout << "MAx ATime: " << _initialDelay << endl;
    // cout << "=========== Arrival Time ===========" << endl;

    // cout << "=========== Required Time ===========" << endl;
    calRTime();
    // cout << "=========== Required Time ===========" << endl;

    // cout << "=========== Slack ===========" << endl;
    calSlack();
    // cout << "=========== Slack ===========" << endl;

    // cout << "=========== Area ===========" << endl;
    _totalArea = calArea();
    _optArea = _totalArea;
    // cout << "=========== Area ===========" << endl;

    // cout << "=========== Approach ===========" << endl;
    Approach();
    _optArea = calArea();
    // cout << "=========== Approach ===========" << endl;
    
    return;
}

void Tech_map::PrintEachObj()
{
    Abc_Obj_t *node, *fi;
	int i, j;
	
	printf("<< Print Each Obj- >>\n");
	printf(" ID       Name  Type  Level\n");
	printf("--------------------\n");
	Abc_NtkForEachObj(_ntk, node, i){
		printf("%3d %10s %2d %2d\n", node->Id, Abc_ObjName(node), node->Type, node->Level);
	
		Abc_ObjForEachFanin(node, fi, j){
			printf("  %10s %d\n", Abc_ObjName(fi), Abc_ObjFaninC(node, j));
		}
	}
	printf("<< ----- End ----- >>\n");

    return;
}

void Tech_map::writeResult(string output)
{
    fstream out;
    out.open(output, ios::out);
    if (!out) {
        cerr << "Cannot open the output file \"" << output
            << "\". The program will be terminated..." << endl;
        exit(1);
    }

    out << "#Initial delay: " << _initialDelay << endl;
    out << "#Original area: " << _totalArea << endl;
    out << "#Optimized area: " << _optArea << endl;

    for(map<int, Node*>::iterator it = _map_PI.begin(); it != _map_PI.end(); ++it) {
        Node* n = it->second;
        out << "INPUT("<< n->getName() << ")" << endl;
    }
    for(map<int, Node*>::iterator it = _map_PO.begin(); it != _map_PO.end(); ++it) {
        Node* n = it->second;
        out << "OUTPUT("<< n->getName() << ")" << endl;
    }
    for(map<int, Node*>::iterator it = _map_node.begin(); it != _map_node.end(); ++it) {
        Node* n = it->second;
        if(n->getFanInSize() != 0)
        {
            string type = n->getPatternType();
            // cout << type << endl;
            if(type.compare("OUTPUT") == 0) {
                Node* fanin = n->getFanIn(0);
                out << n->getName() << " = BUFF(" << fanin->getName() << ")" << endl;
            }
            else {
                out << n->getName() << " = " << n->getPatternType() << "(";
                // cout << n->getName() << ": " << n->getFanInSize() << endl;
                for(int j = 0; j < n->getFanInSize(); ++j)
                {
                    Node* fanin = n->getFanIn(j);
                    out << fanin->getName();
                    
                    if(j < n->getFanInSize() - 1)
                    {
                        out << ", ";
                    }
                }
                out << ")\t";
                out << "# slack = " << n->getSlack() << endl;
            }
        }
    }
    out.close();

    return;
}