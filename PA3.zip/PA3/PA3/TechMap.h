#ifndef TECHMAP_H
#define TECHMAP_H

#include <vector>
#include <list>
#include <map>
#include <stack>

#include "base/abc/abc.h"
#include "dag.h"

using namespace std;
// index, cp
// index, slack
typedef pair<int, double> Pair;         

extern "C"
{
    // Setup
    extern void Abc_Start();
    extern void Abc_Stop();
    extern Abc_Ntk_t *Io_ReadBlifAsAig(char *, int);
    extern void PrintEachObj(Abc_Ntk_t *ntk);

    // Ntk: Graph
    extern int Abc_NtkObjNum(Abc_Ntk_t *pNtk);
    extern int Abc_NtkPoNum(Abc_Ntk_t *pNtk);
    extern Abc_Obj_t *Abc_NtkObj(Abc_Ntk_t *pNtk, int i);
    extern Abc_Obj_t *Abc_NtkPo(Abc_Ntk_t *pNtk, int i);
    extern int Abc_NtkLevel(Abc_Ntk_t *pNtk);
    extern int Abc_NtkIsAigNetlist(Abc_Ntk_t *pNtk);

    // Obj: Node
    extern char *Abc_ObjName(Abc_Obj_t *pNode);
    extern unsigned Abc_ObjId(Abc_Obj_t *pObj);
    extern int Abc_ObjLevel(Abc_Obj_t *pObj);
    // Obj: Fin Fout of Node
    extern int Abc_ObjFaninNum(Abc_Obj_t *pObj);
    extern int Abc_ObjFaninId(Abc_Obj_t *pObj, int i);
    extern int Abc_ObjFaninC(Abc_Obj_t *pObj, int i);
    extern int Abc_ObjFanoutNum(Abc_Obj_t *pObj);
    extern Abc_Obj_t *Abc_ObjFanin(Abc_Obj_t *pObj, int i);
    
    // 
    extern void util_getopt_reset ARGS((void));
}

// object types
// typedef enum { 
//     ABC_OBJ_NONE = 0,   //  0:  unknown
//     ABC_OBJ_CONST1,     //  1:  constant 1 node (AIG only)
//     ABC_OBJ_PI,         //  2:  primary input terminal
//     ABC_OBJ_PO,         //  3:  primary output terminal
//     ABC_OBJ_BI,         //  4:  box input terminal
//     ABC_OBJ_BO,         //  5:  box output terminal
//     ABC_OBJ_NET,        //  6:  net
//     ABC_OBJ_NODE,       //  7:  node
//     ABC_OBJ_LATCH,      //  8:  latch
//     ABC_OBJ_WHITEBOX,   //  9:  box with known contents
//     ABC_OBJ_BLACKBOX,   // 10:  box with unknown contents
//     ABC_OBJ_NUMBER      // 11:  unused
// } Abc_ObjType_t;

class Tech_map {
public:
    Tech_map(Abc_Ntk_t*  ntk, fstream& inFile) : _ntk(ntk)
    {
        // _dag = new DAG();
        _num_inv = 0;
        _num_lib_inv = 0;
        _num_lib_nand = 0;

        _max_ATime = 0;
        _totalArea = 0;
        _optArea = 0;

        parseLib(inFile);
        initial();
    }
    ~Tech_map() {
       
    }

    // modify method
    void parseLib(fstream& inFile);
    void initial();
    void calATime();
    void calRTime();
    void calSlack();
    double calArea();
    void updateATime(Node* node);
    void updateRTime(Node* node);
    bool updateSlack(Node* node);
    void updateCritical();
    void Approach();
    void techmap();

    // member functions about reporting
    void PrintEachObj();
    void writeResult(string output);

private:
    Abc_Ntk_t*      _ntk;
    // DAG*            _dag;

    double          _initialDelay;
    double          _max_ATime;
    double          _totalArea;
    double          _optArea;

    int             _num_obj;
    int             _num_inv;
    // int             _lastnode;      // Id

    int             _num_lib_inv;
    int             _num_lib_nand;

    // index, Node
    map<int, Node*>     _map_node;  
    map<int, Node*>     _map_PI;
    map<int, Node*>     _map_PO;

    vector<Lib*>        _vec_lib_inv;
    vector<Lib*>        _vec_lib_nand;

    map<string, Lib*>   _map_lib_inv;
    map<string, Lib*>   _map_lib_nand;
};

#endif  // TECHMAP_H