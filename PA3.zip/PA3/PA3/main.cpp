#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <map>
#include "../alanmi-abc-906cecc894b2/src/base/abc/abc.h"
// #include "base/abc/abc.h"
#include "TechMap.h"

using namespace std;

extern "C"
{
    extern void Abc_Start();
    extern void Abc_Stop();
    extern void util_getopt_reset ARGS((void));
    extern void PrintEachObj(Abc_Ntk_t *ntk);
    extern Abc_Ntk_t *Io_ReadBlifAsAig(char *, int);
    extern unsigned Abc_ObjId(Abc_Obj_t *pObj);
    extern int Abc_NtkIsAigNetlist(Abc_Ntk_t *pNtk);
    extern int Abc_NtkLevel(Abc_Ntk_t *pNtk);
    extern int Abc_ObjFaninNum(Abc_Obj_t *pObj);
    extern int Abc_ObjFaninId(Abc_Obj_t *pObj, int i);
    extern int Abc_ObjFaninC(Abc_Obj_t *pObj, int i);
    extern int Abc_ObjFanoutNum(Abc_Obj_t *pObj);
    extern int Abc_ObjLevel(Abc_Obj_t *pObj);
    extern int Abc_NtkObjNum(Abc_Ntk_t *pNtk);
    extern int Abc_NtkPoNum(Abc_Ntk_t *pNtk);
    extern Abc_Obj_t *Abc_NtkObj(Abc_Ntk_t *pNtk, int i);
    extern Abc_Obj_t *Abc_NtkPo(Abc_Ntk_t *pNtk, int i);
    extern Abc_Obj_t *Abc_ObjFanin(Abc_Obj_t *pObj, int i);
    extern char *Abc_ObjName(Abc_Obj_t *pNode);
}

int main(int argc, char **argv)
{
	Abc_Ntk_t*  ntk;
	string infile, outfile, libfile;
	fstream lib;
	
    if (argc == 3) {
        lib.open(argv[2], ios::in);
        if (!lib) {
            cerr << "Cannot open the lib file \"" << argv[2]
                 << "\". The program will be terminated..." << endl;
            exit(1);
        }
    }
    else {
        cerr << "Usage: ./ace BLIF_FILE LIB_FILE" << endl;
        exit(1);
    }
	infile = argv[1];
	outfile = infile.substr(infile.rfind('/')+1, infile.rfind('.')-infile.rfind('/')-1) + ".mbench";

	// << Setup ABC >>
	 Abc_Start();
	 // << Read blif file >>
	 if (!(ntk = Io_ReadBlifAsAig(argv[1], 1))) return 1;  
	
	// <Technology Mapping>
	Tech_map* tm = new Tech_map(ntk, lib);
	tm->techmap();
	tm->writeResult(outfile);
	
	Abc_NtkDelete(ntk);
	// << End ABC >>
	 Abc_Stop();
	
	return 1;
}
