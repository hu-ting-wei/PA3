1. 學號：M11207402
2. 姓名：張晏晟
3. 使用之程式語言：C++
4. 使用之編譯平台：Linux GNU g++
5. 檔案壓縮方式: M11207402.zip
6. 各檔案說明：
	  M11207402/TechMap		: 執行檔
	  M11207402/main.cpp		: 主程式source code
	  M11207402/TechMap.cpp	: cpp file 
	  M11207402/TechMap.h		: header file
	  M11207402/dag.h			: header file
	  M11207402/Makefile		: Makefile
	  M11207402/*.mbench		: Mapping result
	  M11207402/readme.txt		: 本檔案
7. 編譯方式說明：        	
   主程式：
	 在 M11207402/ 這個資料夾下指令 : make
	 即可在 ./ 產生 ./TechMap 的執行檔
	
8. 執行、使用方式說明：
   主程式：
	compile 完成後，在 /M11207402/ 目錄下會產生一個 TechMap 的執行檔
	
	在 M11207402/ 下指令，執行檔的命令格式為 :
     	./TechMap BLIF_FILE LIB_FILE

9. 備註：
	需要將 ABC 的資料夾放在 Makefile 的前一層路徑: 
		ABC = ../alanmi-abc-906cecc894b2
    