#ifndef DAG_H
#define DAG_H

#include <stdio.h>
#include <vector>
#include <map>

#include "base/abc/abc.h"

using namespace std;
enum gate_type {GNAND, GINV};

class Node {
    // friend class DAG;
public:
    Node(int id) : _id(id)
    {
        _ATime = 0;
        _RTime = 0;
        _slack = 0;
        _area = 0;
        _delay = 0;
        _isPI = false;
        _isPO = false;
        _isCritical = false;
    }
    ~Node();

    // Set function
    void setId(int id)                          { _id = id; }
    void addFanIn(Node* fanIn)                  { _fanIn.push_back(fanIn); }
    void addFanOut(Node* fanOut)                { _fanOut.push_back(fanOut); }
    void setLevel(double level)                 { _level = level; }
    void setName(string name)                   { _name = name; } 
    void setGateType(Abc_ObjType_t gateType)    { _gateType = gateType; }
    void setPatternType(string type)            { _patternType = type; }
    void setATime(double arrivalTime)           { _ATime = arrivalTime; }
    void setRTime(double requireTime)           { _RTime = requireTime; }
    void setSlack()                             { _slack = _RTime - _ATime; 
                                                    if(_slack < 0 && _slack > -10e9)   _slack = 0; }
    void setArea(double area)                   { _area = area; }
    void setDelay(double delay)                 { _delay = delay; }
    void setCritical()                          { if(_slack < 0.01) _isCritical = true; }
    void setisPI(bool p)                        { _isPI = p; }
    void setisPO(bool p)                        { _isPO = p; }
    void setisNAND(int i)                       { _isNAND = i; }

    // Get function
    int getId()                         { return _id; }
    Node* getFanIn(int i)               { return _fanIn[i]; }
    Node* getFanOut(int i)              { return _fanOut[i]; }
    int getFanInSize()                  { return _fanIn.size(); }
    int getFanOutSize()                 { return _fanOut.size(); }
    double getLevel()                   { return _level; }
    string getName()                    { return _name; }
    Abc_ObjType_t getGateType()         { return _gateType; }
    string getPatternType()             { return _patternType; }
    double getATime()                   { return _ATime; }
    double getRTime()                   { return _RTime; }
    double getSlack()                   { return _slack; }
    double getArea()                    { return _area; }
    double getDelay()                   { return _delay; }
    bool getCritical()                  { return _isCritical; }
    bool getisPI()                      { return _isPI; }
    bool getisPO()                      { return _isPO; }
    int getisNAND()                     { return _isNAND; }

private:
    string          _name;
    Abc_ObjType_t   _gateType;      
    string          _patternType;   // GATE: 1 ~ 4
    int             _isNAND;        // INV: 0, NAND: 1, BUFFER: 2

    int             _id;        // id of the node (indicating the cell)
    double          _level;
    
    double          _ATime;     // Arrival Time
    double          _RTime;     // Required Time
    double          _slack;
    bool            _isPI;
    bool            _isPO;
    bool            _isCritical;
    double          _area;
    double          _delay;

    vector<Node*>   _fanIn;
    vector<Node*>   _fanOut;
};

class Lib {
public:
    Lib(string name) : _name(name) {}
    ~Lib();

    // set funciton
    void setDelayBase(double d)     { _delay_base = d; }
    void setDelayFan(double d)      { _delay_fan = d;  }
    void setArea(double a)          { _area = a; }
    void setCP()                    { _cp = (_delay_base + 2 * _delay_fan) / _area ; }

    // get funciton
    string getName()            { return _name; }
    double getDelayBase()       { return _delay_base; }
    double getDelayFan()        { return _delay_fan; }
    double getArea()            { return _area; }
    double getCP()              { return _cp; }

private:
    string  _name;
    double  _delay_base;
    double  _delay_fan;
    double  _area;
    double  _cp;            // as large as good
};

#endif  // DAG_H